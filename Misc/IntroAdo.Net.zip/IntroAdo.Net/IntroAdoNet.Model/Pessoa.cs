﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntroAdoNet.Model
{
    public class Pessoa
    {
        private IList<Endereco> _enderecos;
        private IList<Telefone> _telefones;
        private IList<Documento> _documentos;

        public Pessoa()
        {
            _enderecos = new List<Endereco>();
            _telefones = new List<Telefone>();
            _documentos = new List<Documento>();
        }

        public virtual Guid Id { get; set; }
        public virtual string Nome { get; set; }

        public virtual IList<Endereco> Enderecos
        {
            get { return _enderecos; }
            set { _enderecos = value; }
        }

        public virtual IList<Telefone> Telefones
        {
            get { return _telefones; }
            set { _telefones = value; }
        }

        public virtual IList<Documento> Documentos
        {
            get { return _documentos; }
            set { _documentos = value; }
        }
    }
}
