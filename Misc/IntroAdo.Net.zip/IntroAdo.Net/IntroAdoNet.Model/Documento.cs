﻿using System;

namespace IntroAdoNet.Model
{
    public class Documento
    {
        public virtual Guid Id { get; set; }
        public virtual string Tipo { get; set; }
        public virtual string Numero { get; set; }
        public virtual DateTime DataDeEmissao { get; set; }
        public virtual DateTime DataDeValidade { get; set; }
    }
}