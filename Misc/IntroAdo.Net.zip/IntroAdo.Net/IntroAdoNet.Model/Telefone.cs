﻿using System;

namespace IntroAdoNet.Model
{
    public class Telefone
    {
        public virtual Guid Id { get; set; }
        public virtual int DDD { get; set; }
        public virtual int Numero { get; set; }

        public virtual TipoDeTelefone TipoDeTelefone { get; set; }

        public override string ToString()
        {
            return string.Format("({0}) {1}", DDD, Numero);
        }
    }

    public enum TipoDeTelefone
    {
        Residencial = 0,
        Comercial,
        Celular
    }
}