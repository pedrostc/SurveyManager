﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IntroAdoNet.Dal.SqlServerProvider;
using IntroAdoNet.Model;
using NUnit.Framework;

namespace IntroAdoNet.Dal.SqlServerProviderTest
{
    [TestFixture]
    public class SqlServerProviderTest
    {
        [Test]
        public void LerBancoCadastroTabelaPessoa()
        {
            PessoaDao pessoaDao = new PessoaDao();
            string nomeRetornado = pessoaDao.RetornaNomeDaPrimeiraPessoa();

            Assert.That(nomeRetornado, Is.EqualTo("Ubirajara Mendes"));
        }

        [Test]
        public void InserirPessoaNoBancoCadastroTabelaPessoa()
        {
            Pessoa pessoa = new Pessoa()
                {
                    Id = Guid.NewGuid(),
                    Nome = "Ubirajara Junior"
                };

            pessoa.Telefones.Add(new Telefone()
                {
                    Id = Guid.NewGuid(),
                    DDD = 21,
                    Numero = 993901365,
                    TipoDeTelefone = TipoDeTelefone.Celular
                });


            PessoaDao pessoaDao = new PessoaDao();
            Guid idRetornado = pessoaDao.InserirPessoa(pessoa);

            Assert.That(idRetornado, Is.EqualTo(idRetornado));

            int rows = pessoaDao.ExcluirPessoa(idRetornado);

            Assert.That(rows, Is.EqualTo(1));
        }

        [Test]
        public void LerBancoAdventureWorkTabelaPerson()
        {
            AdventureWorksDataAccessObject adventureWorksDataAccessObject = new AdventureWorksDataAccessObject();
            string nomeRetornado = adventureWorksDataAccessObject.RetornaNomeDaPrimeiraPessoa();

            Assert.That(nomeRetornado, Is.EqualTo("Ken"));
        }

        [Test]
        public void InserirPessoaNoBancoAdventureWorkTabelaPerson()
        {
            AdventureWorksDataAccessObject adventureWorksDataAccessObject = new AdventureWorksDataAccessObject();
            int nomeRetornado = adventureWorksDataAccessObject.InserirPessoa();

            Assert.That(nomeRetornado, Is.EqualTo(20778));

            int rows = adventureWorksDataAccessObject.ExcluirPessoa(20778);

            Assert.That(rows, Is.EqualTo(1));
        }
    }
}