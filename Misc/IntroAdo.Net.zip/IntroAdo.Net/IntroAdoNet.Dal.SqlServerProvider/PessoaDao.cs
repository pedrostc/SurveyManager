﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IntroAdoNet.Model;

namespace IntroAdoNet.Dal.SqlServerProvider
{
    public class PessoaDao : SqlDataProviderBase<Pessoa>
    {
        private SqlCommand _command;
        
        public string RetornaNomeDaPrimeiraPessoa()
        {
            Pessoa pessoa = LerDaBaseDeDados("Select * From Pessoa");
            return pessoa.Nome;
        }

        public Guid InserirPessoa(Pessoa pessoa)
        {
            string insertCommand = @"INSERT Pessoa (Id, Nome) VALUES (@Id, @Nome);";

            _command = new SqlCommand(insertCommand);
            _command.Parameters.AddWithValue("@Id", pessoa.Id);
            _command.Parameters.AddWithValue("@Nome", pessoa.Nome);

            InserirNaBaseDeDados(_command);

            pessoa.Telefones.ToList().ForEach(t =>
                {
                    insertCommand = @"INSERT Telefone (Id, DDD, Numero, TipoTelefone, IdPessoa) VALUES (@Id, @DDD, @Numero, @TipoTelefone, @IdPessoa);";
                    _command = new SqlCommand(insertCommand);
                    _command.Parameters.AddWithValue("@Id", t.Id);
                    _command.Parameters.AddWithValue("@DDD", t.DDD);
                    _command.Parameters.AddWithValue("@Numero", t.Numero);
                    _command.Parameters.AddWithValue("@TipoTelefone", t.TipoDeTelefone);
                    _command.Parameters.AddWithValue("@IdPessoa", pessoa.Id);
                    InserirNaBaseDeDados(_command);
                });

            return pessoa.Id;
        }

        public async Task<Guid> InserirPessoaAsync(Pessoa pessoa)
        {
            string insertCommand = @"INSERT Pessoa (Id, Nome) VALUES (@Id, @Nome);";

            _command = new SqlCommand(insertCommand);
            _command.Parameters.AddWithValue("@Id", pessoa.Id);
            _command.Parameters.AddWithValue("@Nome", pessoa.Nome);

            await InserirNaBaseDeDadosAsync(_command);

            return pessoa.Id;
        }

        public int ExcluirPessoa(Guid id)
        {
            string deleteCommand = @"DELETE FROM Pessoa WHERE Id='" + id + "'";

            _command = new SqlCommand(deleteCommand);
            
            return DeletarNaBaseDeDados(_command);
        }

        public override Pessoa MapearBaseObjeto(SqlDataReader reader)
        {
            Pessoa pessoa = new Pessoa();
            while (reader.Read())
            {
                pessoa.Nome = reader["Nome"].ToString();
                break;
            }

            return pessoa;
        }

    }
}