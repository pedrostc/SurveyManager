﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntroAdoNet.Dal.SqlServerProvider
{
    public abstract class SqlDataProviderBase<T>
    {
        private readonly SqlConnection _connection =
            new SqlConnection()
                {
                    ConnectionString =
                        @"Data Source=(localdb)\v11.0;Initial Catalog=AuxiliarDb;Integrated Security=True"
                };

        private SqlCommand _command;

        public T LerDaBaseDeDados(string selectCommandText)
        {
            T t = default(T);

            _connection.Open();

            _command = new SqlCommand(selectCommandText, _connection);
            t = MapearBaseObjeto(_command.ExecuteReader());
            _connection.Close();

            return t;
        }

        public int InserirNaBaseDeDados(SqlCommand command)
        {
            int rowsAffected = 0;
            _connection.Open();
            command.Connection = _connection;
            rowsAffected = command.ExecuteNonQuery();
            _connection.Close();

            return rowsAffected;
        }

        public async Task<int> InserirNaBaseDeDadosAsync(SqlCommand command)
        {
            int rowsAffected = 0;
            _connection.Open();
            command.Connection = _connection;
            rowsAffected = await command.ExecuteNonQueryAsync();
            _connection.Close();

            return rowsAffected;
        }

        public int DeletarNaBaseDeDados(SqlCommand command)
        {
            int rowsAffected = 0;
            _connection.Open();

            command.Connection = _connection;
            rowsAffected = command.ExecuteNonQuery();

            _connection.Close();

            return rowsAffected;
        }

        public abstract T MapearBaseObjeto(SqlDataReader reader);
    }
}