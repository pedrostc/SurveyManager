﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntroAdoNet.Dal.SqlServerProvider
{
    public class TextFileProviderDao
    {
        private string _filePath = string.Empty;

        public TextFileProviderDao(string filePath)
        {
            _filePath = filePath;
        }

        public string LerConteudoDoArquivo()
        {
            string conteudoDoArquivo = string.Empty;

            StreamReader streamReader = new StreamReader(_filePath);
            
            while (streamReader.ReadLine() !=null)
            {
                conteudoDoArquivo += streamReader;
            }

            streamReader.Close();

            return conteudoDoArquivo;
        }

    }
}