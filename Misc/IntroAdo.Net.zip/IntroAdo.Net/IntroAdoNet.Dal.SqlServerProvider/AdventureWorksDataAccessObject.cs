﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntroAdoNet.Dal.SqlServerProvider
{
    public class AdventureWorksDataAccessObject
    {

        public string RetornaNomeDaPrimeiraPessoa()
        {
            string nomeDaPrimeiraPessoa = string.Empty;
            SqlConnection connection =
                new SqlConnection()
                    {
                        ConnectionString =
                            @"Data Source=(localdb)\v11.0;Initial Catalog=AdventureWorks2012;Integrated Security=True"
                    };

            connection.Open();

            SqlCommand command = new SqlCommand("Select * From Person.Person", connection);
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                nomeDaPrimeiraPessoa = reader["FirstName"].ToString();
                break;
            }

            connection.Close();

            return nomeDaPrimeiraPessoa;
        }

        public int InserirPessoa()
        {
            string nomeDaPrimeiraPessoa = string.Empty;
            SqlConnection connection =
                new SqlConnection()
                {
                    ConnectionString =
                        @"Data Source=(localdb)\v11.0;Initial Catalog=AdventureWorks2012;Integrated Security=True"
                };

            connection.Open();

            Guid guid = Guid.NewGuid();

            string insertCommand = @"INSERT INTO Person.BusinessEntity (rowguid, ModifiedDate) 
                    VALUES (@rowguid, @ModifiedDate); SELECT SCOPE_IDENTITY()";

            SqlCommand command = new SqlCommand(insertCommand, connection);
            command.Parameters.AddWithValue("@rowguid", guid);
            command.Parameters.AddWithValue("@ModifiedDate", DateTime.Now);
            Int32 id = (Int32)command.ExecuteScalar();
            
            insertCommand = @"INSERT INTO Person.Person (BusinessEntityID, PersonType, NameStyle, Title, FirstName, MiddleName, LastName, Suffix, EmailPromotion, AdditionalContactInfo, Demographics, rowguid, ModifiedDate) 
                    VALUES (@BusinessEntityID, @PersonType, @NameStyle, @Title, @FirstName, @MiddleName, @LastName, @Suffix, @EmailPromotion, @AdditionalContactInfo, @Demographics, @rowguid, @ModifiedDate); SELECT SCOPE_IDENTITY()";

            command = new SqlCommand(insertCommand, connection);
            command.Parameters.AddWithValue("@BusinessEntityID", id);
            command.Parameters.AddWithValue("@PersonType", "EM");
            command.Parameters.AddWithValue("@NameStyle", 0);
            command.Parameters.AddWithValue("@Title", "");
            command.Parameters.AddWithValue("@FirstName", "Ubirajara");
            command.Parameters.AddWithValue("@MiddleName", "Mendes Nunes");
            command.Parameters.AddWithValue("@LastName", "Junior");
            command.Parameters.AddWithValue("@Suffix", "");
            command.Parameters.AddWithValue("@EmailPromotion", 0);
            command.Parameters.AddWithValue("@AdditionalContactInfo", "");
            command.Parameters.AddWithValue("@Demographics", "");
            command.Parameters.AddWithValue("@rowguid", guid);
            command.Parameters.AddWithValue("@ModifiedDate", DateTime.Now);

            id = (Int32)command.ExecuteScalar();

            connection.Close();

            return id;
        }

        public int ExcluirPessoa(int id)
        {
            SqlConnection connection =
                new SqlConnection()
                {
                    ConnectionString =
                        @"Data Source=(localdb)\v11.0;Initial Catalog=AdventureWorks2012;Integrated Security=True"
                };

            connection.Open();

            string deleteCommand = @"DELETE FROM Person.Person WHERE BusinessEntityID=" + id;

            SqlCommand command = new SqlCommand(deleteCommand, connection);
            Int32 rowsAffected = (Int32)command.ExecuteScalar();

            connection.Close();

            return rowsAffected;
        }


    }
}