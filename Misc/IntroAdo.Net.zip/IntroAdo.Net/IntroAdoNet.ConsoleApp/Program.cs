﻿using IntroAdoNet.Dal.SqlServerProvider;
using IntroAdoNet.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace IntroAdoNet.ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Executor();
            Console.WriteLine("Estou No Main");
            Thread.Sleep(1000);

            InserirPessoaAsync();
            Console.WriteLine("Estou No Main após Async");

            InserirPessoa();
            Console.WriteLine("Estou No Main após Sync");

            Console.ReadLine();
        }

        public static async Task Executor()
        {
            int demorado = await ProcessoDemorado();
            Console.WriteLine(demorado);
        }

        public static async Task<int> ProcessoDemorado()
        {
            await Task.Delay(2000);
            return 1;
        }

        public static async Task InserirPessoa() 
        {
            int index = 0;
            while (true)
            {
                Pessoa pessoa = new Pessoa() { Id = Guid.NewGuid(), Nome = "Pessoa " + index };

                //Random random = new Random();
                //if (random.Next(1, 10) > 5)
                //    Thread.Sleep(500);

                PessoaDao dao = new PessoaDao();
                dao.InserirPessoa(pessoa);

                Console.WriteLine("Inserida Pessoa Sync " + index);
                index++;
            }
        }

        public static async Task InserirPessoaAsync()
        {
            int index = 0;
            while (true)
            {
                Pessoa pessoa = new Pessoa() { Id = Guid.NewGuid(), Nome = "PessoaAsync " + index };

                //Random random = new Random();
                //if (random.Next(1, 10) > 5)
                //    Thread.Sleep(1000);

                PessoaDao dao = new PessoaDao();
                Guid id = await dao.InserirPessoaAsync(pessoa);

                Console.WriteLine("Inserida Pessoa Async " + index);
                index++;
            }
        }
    }
}